﻿using System.Collections.Generic;
using System.Linq;
using OnlineCourseManagementSystem.Interfaces;
using OnlineCourseManagementSystem.Models;

namespace OnlineCourseManagementSystem.Repositories
{
    public class LessonRepository : ILessonRepository
    {
        private readonly List<Lesson> lessons = new List<Lesson>();

        public void Add(Lesson lesson)
        {
            lessons.Add(lesson);
        }

        public List<Lesson> GetAll()
        {
            return lessons;
        }

        public Lesson GetById(int id)
        {
            return lessons.FirstOrDefault(l => l.Id == id);
        }

        public void Update(Lesson lesson)
        {
            Lesson existingLesson = GetById(lesson.Id);

            if (existingLesson != null)
            {
                existingLesson.Title = lesson.Title;
                existingLesson.Description = lesson.Description;
                existingLesson.CourseId = lesson.CourseId;
                existingLesson.DurationInMinutes = lesson.DurationInMinutes;
            }
        }

        public void Delete(int id)
        {
            Lesson lesson = GetById(id);

            if (lesson != null)
            {
                lessons.Remove(lesson);
            }
        }
    }
}