﻿using System;
using OnlineCourseManagementSystem.Interfaces;
using OnlineCourseManagementSystem.Models;

namespace OnlineCourseManagementSystem.Services
{
    public class LessonManager
    {
        private readonly ILessonRepository repository;

        public LessonManager(ILessonRepository repository)
        {
            this.repository = repository;
        }

        public void AddLesson(Lesson lesson)
        {
            if (repository.GetById(lesson.Id) != null)
            {
                Console.WriteLine("Lesson ID already exists!");
                return;
            }

            repository.Add(lesson);

            Console.WriteLine("Lesson added successfully!");
        }

        public void ShowAllLessons()
        {
            var lessons = repository.GetAll();

            if (lessons.Count == 0)
            {
                Console.WriteLine("No lessons found.");
                return;
            }

            foreach (var lesson in lessons)
            {
                lesson.ShowInfo();
            }
        }

        public void ShowLessonsByCourseId(int courseId)
        {
            bool found = false;

            foreach (var lesson in repository.GetAll())
            {
                if (lesson.CourseId == courseId)
                {
                    lesson.ShowInfo();
                    found = true;
                }
            }

            if (!found)
            {
                Console.WriteLine("No lessons found for this course.");
            }
        }

        public void UpdateLesson(int id, string title, string description, int duration)
        {
            Lesson lesson = repository.GetById(id);

            if (lesson == null)
            {
                Console.WriteLine("Lesson not found!");
                return;
            }

            lesson.Title = title;
            lesson.Description = description;
            lesson.DurationInMinutes = duration;

            repository.Update(lesson);

            Console.WriteLine("Lesson updated successfully!");
        }

        public void DeleteLesson(int id)
        {
            Lesson lesson = repository.GetById(id);

            if (lesson == null)
            {
                Console.WriteLine("Lesson not found!");
                return;
            }

            repository.Delete(id);

            Console.WriteLine("Lesson deleted successfully!");
        }
    }
}