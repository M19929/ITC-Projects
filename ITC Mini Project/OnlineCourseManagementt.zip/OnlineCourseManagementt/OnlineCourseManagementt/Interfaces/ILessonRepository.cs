﻿using System.Collections.Generic;
using OnlineCourseManagementSystem.Models;

namespace OnlineCourseManagementSystem.Interfaces
{
    public interface ILessonRepository
    {
        void Add(Lesson lesson);

        List<Lesson> GetAll();

        Lesson GetById(int id);

        void Update(Lesson lesson);

        void Delete(int id);
    }
}