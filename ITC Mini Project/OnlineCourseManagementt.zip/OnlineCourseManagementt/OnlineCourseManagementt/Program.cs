﻿using System;
using OnlineCourseManagementSystem.Models;
using OnlineCourseManagementSystem.Interfaces;
using OnlineCourseManagementSystem.Repositories;
using OnlineCourseManagementSystem.Services;

namespace OnlineCourseManagementSystem
{
    public class Program
    {
        static void Main(string[] args)
        {
            Repositories.LessonRepository repository = new Repositories.LessonRepository();

            LessonManager manager = new LessonManager(repository);

            bool running = true;

            while (running)
            {
                Console.WriteLine("\n===== Lessons Management =====");
                Console.WriteLine("1. Add New Lesson");
                Console.WriteLine("2. Show All Lessons");
                Console.WriteLine("3. Show Lessons by Course ID");
                Console.WriteLine("4. Update Lesson");
                Console.WriteLine("5. Delete Lesson");
                Console.WriteLine("6. Exit");
                Console.Write("Choose an option: ");

                if (!int.TryParse(Console.ReadLine(), out int choice))
                {
                    Console.WriteLine("Please enter a valid number.");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        Console.Write("Enter Lesson ID: ");

                        if (!int.TryParse(Console.ReadLine(), out int id))
                        {
                            Console.WriteLine("Invalid Lesson ID.");
                            break;
                        }

                        Console.Write("Enter Lesson Title: ");
                        string title = Console.ReadLine() ?? "";

                        Console.Write("Enter Lesson Description: ");
                        string description = Console.ReadLine() ?? "";

                        Console.Write("Enter Course ID: ");

                        if (!int.TryParse(Console.ReadLine(), out int courseId))
                        {
                            Console.WriteLine("Invalid Course ID.");
                            break;
                        }

                        Console.Write("Enter Duration in Minutes: ");

                        if (!int.TryParse(Console.ReadLine(), out int duration) ||
                            duration <= 0)
                        {
                            Console.WriteLine("Duration must be a positive number.");
                            break;
                        }

                        Lesson lesson = new Lesson(
                            id,
                            title,
                            description,
                            courseId,
                            duration
                        );

                        manager.AddLesson(lesson);
                        break;

                    case 2:
                        manager.ShowAllLessons();
                        break;

                    case 3:
                        Console.Write("Enter Course ID: ");

                        if (!int.TryParse(Console.ReadLine(), out int searchCourseId))
                        {
                            Console.WriteLine("Invalid Course ID.");
                            break;
                        }

                        manager.ShowLessonsByCourseId(searchCourseId);
                        break;

                    case 4:
                        Console.Write("Enter Lesson ID to Update: ");

                        if (!int.TryParse(Console.ReadLine(), out int updateId))
                        {
                            Console.WriteLine("Invalid Lesson ID.");
                            break;
                        }

                        Console.Write("Enter New Title: ");
                        string newTitle = Console.ReadLine() ?? "";

                        Console.Write("Enter New Description: ");
                        string newDescription = Console.ReadLine() ?? "";

                        Console.Write("Enter New Duration: ");

                        if (!int.TryParse(Console.ReadLine(), out int newDuration) ||
                            newDuration <= 0)
                        {
                            Console.WriteLine("Duration must be a positive number.");
                            break;
                        }

                        manager.UpdateLesson(
                            updateId,
                            newTitle,
                            newDescription,
                            newDuration
                        );

                        break;

                    case 5:
                        Console.Write("Enter Lesson ID to Delete: ");

                        if (!int.TryParse(Console.ReadLine(), out int deleteId))
                        {
                            Console.WriteLine("Invalid Lesson ID.");
                            break;
                        }

                        manager.DeleteLesson(deleteId);
                        break;

                    case 6:
                        running = false;
                        Console.WriteLine("Goodbye!");
                        break;

                    default:
                        Console.WriteLine("Invalid choice. Try again.");
                        break;
                }
            }
        }
    }
}